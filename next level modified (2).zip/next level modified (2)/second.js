const mohit = {
  name: "Mohit",
  age: 22
};

export default mohit;
